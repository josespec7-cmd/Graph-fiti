package com.example

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

data class FunctionItem(
    val id: Int,
    val tabLabel: String, // e.g. "Y₁", "Y₂"
    val formula: String,
    val color: Color,
    val isVisible: Boolean = true,
    val isValid: Boolean = true,
    val errorMessage: String? = null,
    val parsedExpr: ExprNode? = null
)

data class Viewport(
    val xMin: Double = -10.0,
    val xMax: Double = 10.0,
    val yMin: Double = -10.0,
    val yMax: Double = 10.0
)

data class GraphUiState(
    val functions: List<FunctionItem> = listOf(
        FunctionItem(1, "Y₁", "x^2 - 3", Color(0xFF00E5FF)),
        FunctionItem(2, "Y₂", "3sin(x)", Color(0xFFFFB300))
    ),
    val activeFunctionId: Int = 1,
    val viewport: Viewport = Viewport(),
    val showGrid: Boolean = true,
    val showAxes: Boolean = true,
    val equalScale: Boolean = false,
    val traceX: Double? = null, // mathematical X coordinate currently being hovered/traced
    val cursorPosition: Int = 0, // Cursor position inside active text field (helps key insertions)
    val history: List<String> = listOf("x^2 - 3", "3sin(x)", "sin(x) + cos(2x)", "x^3 - 2x", "sqrt(x)") // Pre-seeded math history
)

class GraphViewModel : ViewModel() {
    private val _uiState = MutableStateFlow(GraphUiState())
    val uiState: StateFlow<GraphUiState> = _uiState.asStateFlow()

    private val availableColors = listOf(
        Color(0xFF00E5FF), // Cyan
        Color(0xFFFFB300), // Amber
        Color(0xFFD500F9), // Violet
        Color(0xFFFF4081), // Pink
        Color(0xFF00E676)  // Emerald Green
    )

    init {
        // Initial parse
        _uiState.update { state ->
            state.copy(functions = state.functions.map { parseFunction(it) })
        }
    }

    private fun parseFunction(item: FunctionItem): FunctionItem {
        if (item.formula.isBlank()) {
            return item.copy(isValid = true, errorMessage = null, parsedExpr = null)
        }
        return try {
            val expr = MathParser.parse(item.formula)
            // Add valid formula to history automatically if it's not already present
            addToHistoryList(item.formula)
            item.copy(isValid = true, errorMessage = null, parsedExpr = expr)
        } catch (e: Exception) {
            item.copy(isValid = false, errorMessage = "Check your expression", parsedExpr = null)
        }
    }

    private fun addToHistoryList(formula: String) {
        if (formula.isBlank() || formula.length < 2) return
        _uiState.update { state ->
            if (state.history.contains(formula)) {
                state
            } else {
                state.copy(history = (listOf(formula) + state.history).take(15))
            }
        }
    }

    fun selectTab(id: Int) {
        _uiState.update { it.copy(activeFunctionId = id, cursorPosition = getFunctionFormula(id).length) }
    }

    private fun getFunctionFormula(id: Int): String {
        return _uiState.value.functions.find { it.id == id }?.formula ?: ""
    }

    fun updateActiveFormula(newFormula: String, newCursor: Int? = null) {
        _uiState.update { state ->
            val updated = state.functions.map {
                if (it.id == state.activeFunctionId) {
                    val temp = it.copy(formula = newFormula)
                    // We parse it inside state updates
                    try {
                        val expr = MathParser.parse(newFormula)
                        if (newFormula.isNotBlank() && newFormula.length >= 2) {
                            // Valid non-empty formula -> we can auto-add it to history or do it via custom check
                        }
                        temp.copy(isValid = true, errorMessage = null, parsedExpr = expr)
                    } catch (e: Exception) {
                        temp.copy(isValid = false, errorMessage = "Check your expression", parsedExpr = null)
                    }
                } else {
                    it
                }
            }

            // Keep track of valid additions to history list
            val activeFormula = updated.find { it.id == state.activeFunctionId }?.formula ?: ""
            val nextHistory = if (activeFormula.isNotBlank() && activeFormula.length >= 2 && !state.history.contains(activeFormula)) {
                try {
                    MathParser.parse(activeFormula)
                    (listOf(activeFormula) + state.history).take(15)
                } catch (e: Exception) {
                    state.history
                }
            } else {
                state.history
            }

            state.copy(
                functions = updated,
                cursorPosition = newCursor ?: newFormula.length,
                history = nextHistory
            )
        }
    }

    fun insertAtCursor(textToInsert: String) {
        val activeId = _uiState.value.activeFunctionId
        val formula = getFunctionFormula(activeId)
        val cursor = _uiState.value.cursorPosition

        val start = formula.substring(0, cursor.coerceIn(0, formula.length))
        val end = formula.substring(cursor.coerceIn(0, formula.length))
        val updatedFormula = start + textToInsert + end
        val updatedCursor = cursor + textToInsert.length

        updateActiveFormula(updatedFormula, updatedCursor)
    }

    fun moveCursorLeft() {
        _uiState.update { state ->
            val formula = getFunctionFormula(state.activeFunctionId)
            val newCursor = (state.cursorPosition - 1).coerceIn(0, formula.length)
            state.copy(cursorPosition = newCursor)
        }
    }

    fun moveCursorRight() {
        _uiState.update { state ->
            val formula = getFunctionFormula(state.activeFunctionId)
            val newCursor = (state.cursorPosition + 1).coerceIn(0, formula.length)
            state.copy(cursorPosition = newCursor)
        }
    }

    fun deleteLast() {
        val activeId = _uiState.value.activeFunctionId
        val formula = getFunctionFormula(activeId)
        val cursor = _uiState.value.cursorPosition

        if (cursor > 0 && formula.isNotEmpty()) {
            // Check for special functions or keywords to delete atomically
            val leftOfCursor = formula.substring(0, cursor)
            val keywords = listOf("sin(", "cos(", "tan(", "sqrt(", "log(", "abs(", "ln(")
            var deleteLen = 1
            for (kw in keywords) {
                if (leftOfCursor.endsWith(kw)) {
                    deleteLen = kw.length
                    break
                }
            }

            val start = formula.substring(0, cursor - deleteLen)
            val end = formula.substring(cursor)
            val updatedFormula = start + end
            val updatedCursor = cursor - deleteLen

            updateActiveFormula(updatedFormula, updatedCursor)
        }
    }

    fun clearActiveFormula() {
        updateActiveFormula("", 0)
    }

    fun toggleVisibility(id: Int) {
        _uiState.update { state ->
            state.copy(functions = state.functions.map {
                if (it.id == id) it.copy(isVisible = !it.isVisible) else it
            })
        }
    }

    fun addFunction() {
        _uiState.update { state ->
            if (state.functions.size >= 5) return@update state
            val nextId = (state.functions.maxOfOrNull { it.id } ?: 0) + 1
            val label = "Y" + getSubscript(nextId)
            val color = availableColors[state.functions.size % availableColors.size]
            val newItem = FunctionItem(nextId, label, "", color)
            state.copy(
                functions = state.functions + newItem,
                activeFunctionId = nextId,
                cursorPosition = 0
            )
        }
    }

    fun removeFunction(id: Int) {
        _uiState.update { state ->
            if (state.functions.size <= 1) return@update state // Keep at least one
            val filtered = state.functions.filter { it.id != id }
            val nextActiveId = if (state.activeFunctionId == id) {
                filtered.first().id
            } else {
                state.activeFunctionId
            }
            state.copy(
                functions = filtered,
                activeFunctionId = nextActiveId,
                cursorPosition = (filtered.find { it.id == nextActiveId }?.formula?.length ?: 0)
            )
        }
    }

    private fun getSubscript(num: Int): String {
        return when (num) {
            1 -> "₁"
            2 -> "₂"
            3 -> "₃"
            4 -> "₄"
            5 -> "₅"
            else -> num.toString()
        }
    }

    fun setViewport(xMin: Double, xMax: Double, yMin: Double, yMax: Double) {
        _uiState.update { state ->
            state.copy(viewport = Viewport(xMin, xMax, yMin, yMax))
        }
        if (_uiState.value.equalScale) {
            enforceEqualScaleInternal()
        }
    }

    fun updateViewportDelta(dx: Double, dy: Double) {
        _uiState.update { state ->
            val vp = state.viewport
            val nVp = Viewport(
                xMin = vp.xMin + dx,
                xMax = vp.xMax + dx,
                yMin = vp.yMin + dy,
                yMax = vp.yMax + dy
            )
            state.copy(viewport = nVp)
        }
    }

    fun updateViewportScale(zoomFactor: Double, cxMath: Double, cyMath: Double) {
        _uiState.update { state ->
            val vp = state.viewport
            val dx = vp.xMax - vp.xMin
            val dy = vp.yMax - vp.yMin

            val newDx = dx / zoomFactor
            val newDy = dy / zoomFactor

            val fx = (cxMath - vp.xMin) / dx
            val fy = (cyMath - vp.yMin) / dy

            val newXMin = cxMath - fx * newDx
            val newXMax = newXMin + newDx
            val newYMin = cyMath - fy * newDy
            val newYMax = newYMin + newDy

            state.copy(viewport = Viewport(newXMin, newXMax, newYMin, newYMax))
        }
        if (_uiState.value.equalScale) {
            enforceEqualScaleInternal()
        }
    }

    fun resetView() {
        _uiState.update { state ->
            state.copy(viewport = Viewport(-10.0, 10.0, -10.0, 10.0))
        }
        if (_uiState.value.equalScale) {
            enforceEqualScaleInternal()
        }
    }

    fun toggleGrid(show: Boolean) {
        _uiState.update { it.copy(showGrid = show) }
    }

    fun toggleAxes(show: Boolean) {
        _uiState.update { it.copy(showAxes = show) }
    }

    fun toggleEqualScale(enable: Boolean, widthPx: Float, heightPx: Float) {
        _uiState.update { it.copy(equalScale = enable) }
        if (enable) {
            enforceEqualScale(widthPx, heightPx)
        }
    }

    // Force equal scale based on a known canvas dimension in pixels
    fun enforceEqualScale(widthPx: Float, heightPx: Float) {
        if (widthPx <= 0 || heightPx <= 0) return
        _uiState.update { state ->
            val vp = state.viewport
            val dx = vp.xMax - vp.xMin
            val targetDy = dx * (heightPx / widthPx)
            val yMid = (vp.yMin + vp.yMax) / 2.0
            state.copy(viewport = Viewport(
                xMin = vp.xMin,
                xMax = vp.xMax,
                yMin = yMid - targetDy / 2.0,
                yMax = yMid + targetDy / 2.0
            ))
        }
    }

    private fun enforceEqualScaleInternal() {
        // Enforces scale assuming width and height are reasonably proportional
        // Real-time canvas calls enforceEqualScale explicitly during drawing/sizing
    }

    fun setTraceX(xMath: Double?) {
        _uiState.update { it.copy(traceX = xMath) }
    }

    fun applyPreset(presetName: String) {
        val formula = when (presetName.lowercase()) {
            "linear" -> "2x - 3"
            "quadratic" -> "x^2 - 4"
            "trig" -> "sin(x) + cos(2x)"
            "binomial" -> "(x - 2)(x + 2)"
            else -> ""
        }
        updateActiveFormula(formula, formula.length)
    }

    fun setCursorPos(pos: Int) {
        _uiState.update { it.copy(cursorPosition = pos.coerceIn(0, getFunctionFormula(it.activeFunctionId).length)) }
    }
}
