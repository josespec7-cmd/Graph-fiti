package com.example

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.OutputStream
import kotlin.math.*

@Composable
fun InteractiveGraphCanvas(
    viewModel: GraphViewModel,
    modifier: Modifier = Modifier,
    uiState: GraphUiState
) {
    val context = LocalContext.current
    val density = LocalDensity.current
    val viewport = uiState.viewport
    val functions = uiState.functions
    val activeFunctionId = uiState.activeFunctionId
    val traceX = uiState.traceX

    fun pixelToMathX(px: Float, widthPx: Float): Double {
        return viewport.xMin + (px / widthPx) * (viewport.xMax - viewport.xMin)
    }

    fun pixelToMathY(py: Float, heightPx: Float): Double {
        return viewport.yMin + (1.0 - py / heightPx) * (viewport.yMax - viewport.yMin)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFF0B1120))
            .pointerInput(viewport, uiState.equalScale) {
                // Handle Tap to Set Tracing Coordinate
                detectTapGestures { offset ->
                    val width = size.width.toFloat()
                    val mx = pixelToMathX(offset.x, width)
                    viewModel.setTraceX(mx)
                }
            }
            .pointerInput(viewport, uiState.equalScale) {
                // Handle Pan and Zoom
                detectTransformGestures { centroid, pan, zoom, _ ->
                    val width = size.width.toFloat()
                    val height = size.height.toFloat()

                    // Update scale or pan
                    if (zoom != 1f) {
                        val cxMath = pixelToMathX(centroid.x, width)
                        val cyMath = pixelToMathY(centroid.y, height)
                        viewModel.updateViewportScale(zoom.toDouble(), cxMath, cyMath)
                    } else {
                        val dx = -(pan.x / width) * (viewport.xMax - viewport.xMin)
                        val dy = (pan.y / height) * (viewport.yMax - viewport.yMin)
                        viewModel.updateViewportDelta(dx, dy)
                    }

                    // Update trace at the gesture center
                    val tx = pixelToMathX(centroid.x, width)
                    viewModel.setTraceX(tx)
                }
            }
    ) {
        Canvas(
            modifier = Modifier
                .fillMaxSize()
                .pointerInput(Unit) {
                    // This allows us to track canvas size changes for equal scale
                    viewModel.enforceEqualScale(size.width.toFloat(), size.height.toFloat())
                }
        ) {
            // Trigger size-dependent scale calculation if equal scale is on
            if (uiState.equalScale) {
                viewModel.enforceEqualScale(size.width, size.height)
            }

            drawGraphContent(
                viewport = viewport,
                showGrid = uiState.showGrid,
                showAxes = uiState.showAxes,
                functions = functions,
                activeFunctionId = activeFunctionId,
                traceX = traceX
            )
        }

        // Floating precision coordinate display overlay in the bottom-left corner
        if (traceX != null) {
            val activeFn = functions.find { it.id == activeFunctionId }
            if (activeFn != null && activeFn.isVisible && activeFn.isValid && activeFn.parsedExpr != null) {
                val traceY = activeFn.parsedExpr.evaluate(traceX)
                if (!traceY.isNaN() && !traceY.isInfinite()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                            .background(Color(0xE00F172A), shape = androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                            .padding(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "X: ${String.format("%.4f", traceX)}  Y: ${String.format("%.4f", traceY)}",
                            color = activeFn.color,
                            fontSize = 12.sp,
                            fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace
                        )
                    }
                }
            }
        }
    }
}

fun DrawScope.drawGraphContent(
    viewport: Viewport,
    showGrid: Boolean,
    showAxes: Boolean,
    functions: List<FunctionItem>,
    activeFunctionId: Int,
    traceX: Double?
) {
    val width = size.width
    val height = size.height
    if (width <= 0 || height <= 0) return

    val xMin = viewport.xMin
    val xMax = viewport.xMax
    val yMin = viewport.yMin
    val yMax = viewport.yMax

    fun mathToPixelX(x: Double): Float = ((x - xMin) / (xMax - xMin) * width).toFloat()
    fun mathToPixelY(y: Double): Float = (height - (y - yMin) / (yMax - yMin) * height).toFloat()

    // Clear Background
    drawRect(color = Color(0xFF0F172A))

    // Grid lines
    if (showGrid) {
        val xStep = calculateGridStep(xMax - xMin)
        val xStart = ceil(xMin / xStep) * xStep
        var currentX = xStart
        while (currentX <= xMax) {
            val px = mathToPixelX(currentX)
            val gridColor = if (abs(currentX) < 1e-9) Color(0x5564748B) else Color(0x1F64748B)
            drawLine(
                color = gridColor,
                start = Offset(px, 0f),
                end = Offset(px, height),
                strokeWidth = if (abs(currentX) < 1e-9) 2f else 1f
            )
            currentX += xStep
        }

        val yStep = calculateGridStep(yMax - yMin)
        val yStart = ceil(yMin / yStep) * yStep
        var currentY = yStart
        while (currentY <= yMax) {
            val py = mathToPixelY(currentY)
            val gridColor = if (abs(currentY) < 1e-9) Color(0x5564748B) else Color(0x1F64748B)
            drawLine(
                color = gridColor,
                start = Offset(0f, py),
                end = Offset(width, py),
                strokeWidth = if (abs(currentY) < 1e-9) 2f else 1f
            )
            currentY += yStep
        }
    }

    // Axes lines
    if (showAxes) {
        if (0.0 in yMin..yMax) {
            val py = mathToPixelY(0.0)
            drawLine(
                color = Color(0xFF94A3B8),
                start = Offset(0f, py),
                end = Offset(width, py),
                strokeWidth = 3f
            )
        }
        if (0.0 in xMin..xMax) {
            val px = mathToPixelX(0.0)
            drawLine(
                color = Color(0xFF94A3B8),
                start = Offset(px, 0f),
                end = Offset(px, height),
                strokeWidth = 3f
            )
        }
    }

    // Numeric scale markers
    drawContext.canvas.nativeCanvas.apply {
        val paint = Paint().apply {
            color = android.graphics.Color.parseColor("#94A3B8")
            textSize = 26f
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.NORMAL)
            textAlign = Paint.Align.CENTER
        }

        if (showGrid) {
            val xStep = calculateGridStep(xMax - xMin)
            val xStart = ceil(xMin / xStep) * xStep
            var currentX = xStart
            while (currentX <= xMax) {
                if (abs(currentX) > 1e-9) {
                    val px = mathToPixelX(currentX)
                    val py = if (0.0 in yMin..yMax) {
                        (mathToPixelY(0.0) + 32f).coerceIn(40f, height - 20f)
                    } else {
                        height - 25f
                    }
                    drawText(formatValue(currentX), px, py, paint)
                }
                currentX += xStep
            }

            val yStep = calculateGridStep(yMax - yMin)
            val yStart = ceil(yMin / yStep) * yStep
            var currentY = yStart
            paint.textAlign = Paint.Align.LEFT
            while (currentY <= yMax) {
                if (abs(currentY) > 1e-9) {
                    val py = mathToPixelY(currentY)
                    val px = if (0.0 in xMin..xMax) {
                        (mathToPixelX(0.0) + 15f).coerceIn(15f, width - 120f)
                    } else {
                        15f
                    }
                    drawText(formatValue(currentY), px, py + 8f, paint)
                }
                currentY += yStep
            }
        }
    }

    // Draw Function curves
    functions.forEach { fn ->
        if (!fn.isVisible || !fn.isValid || fn.formula.isBlank() || fn.parsedExpr == null) {
            return@forEach
        }

        val strokeColor = fn.color
        val steps = 400
        var currentPath = Path()
        var pathStarted = false
        var lastY = Double.NaN

        for (i in 0..steps) {
            val px = (i.toFloat() / steps) * width
            val mx = xMin + (i.toDouble() / steps) * (xMax - xMin)
            val my = fn.parsedExpr.evaluate(mx)

            if (my.isNaN() || my.isInfinite()) {
                pathStarted = false
                lastY = Double.NaN
                continue
            }

            val py = mathToPixelY(my)

            // Prevent vertical asymptote spikes (e.g. y = tan(x) or 1/x)
            val extremeJump = !lastY.isNaN() && (
                abs(my - lastY) > (yMax - yMin) * 2.5 && (my * lastY < 0)
            )

            if (extremeJump || py < -1000f || py > height + 1000f) {
                pathStarted = false
            }

            if (!pathStarted) {
                if (py in -500f..(height + 500f)) {
                    currentPath.moveTo(px, py)
                    pathStarted = true
                }
            } else {
                if (py in -500f..(height + 500f)) {
                    currentPath.lineTo(px, py)
                } else {
                    pathStarted = false
                }
            }
            lastY = my
        }

        drawPath(
            path = currentPath,
            color = strokeColor,
            style = Stroke(width = 4f)
        )
    }

    // Draw Crosshairs
    if (traceX != null) {
        val activeFn = functions.find { it.id == activeFunctionId }
        if (activeFn != null && activeFn.isVisible && activeFn.isValid && activeFn.parsedExpr != null) {
            val traceY = activeFn.parsedExpr.evaluate(traceX)
            if (!traceY.isNaN() && !traceY.isInfinite()) {
                val tPx = mathToPixelX(traceX)
                val tPy = mathToPixelY(traceY)

                if (tPx in 0f..width && tPy in 0f..height) {
                    // Vertical dashed line
                    drawLine(
                        color = Color(0x7794A3B8),
                        start = Offset(tPx, 0f),
                        end = Offset(tPx, height),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f))
                    )

                    // Horizontal dashed line
                    drawLine(
                        color = Color(0x7794A3B8),
                        start = Offset(0f, tPy),
                        end = Offset(width, tPy),
                        strokeWidth = 2f,
                        pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 12f))
                    )

                    // Coordinate intersection bubble
                    drawCircle(
                        color = Color.White,
                        radius = 8.dp.toPx(),
                        center = Offset(tPx, tPy)
                    )
                    drawCircle(
                        color = activeFn.color,
                        radius = 5.dp.toPx(),
                        center = Offset(tPx, tPy)
                    )
                }
            }
        }
    }
}

fun calculateGridStep(span: Double): Double {
    if (span <= 0) return 1.0
    val log = log10(span)
    val power = floor(log).toInt()
    val base = span / 10.0.pow(power)
    val step = if (base < 1.5) {
        0.1 * 10.0.pow(power)
    } else if (base < 3.5) {
        0.2 * 10.0.pow(power)
    } else if (base < 7.5) {
        0.5 * 10.0.pow(power)
    } else {
        1.0 * 10.0.pow(power)
    }
    return step
}

fun formatValue(v: Double): String {
    if (abs(v) < 1e-9) return "0"
    return if (abs(v) >= 1e4 || abs(v) < 1e-2) {
        String.format("%.2e", v)
    } else {
        if (v == v.toInt().toDouble()) {
            v.toInt().toString()
        } else {
            String.format("%.2f", v)
        }
    }
}

// Function to export offscreen PNG and download/save directly to public Pictures MediaStore
fun exportAndSaveGraph(
    context: Context,
    viewport: Viewport,
    showGrid: Boolean,
    showAxes: Boolean,
    functions: List<FunctionItem>,
    activeFunctionId: Int,
    traceX: Double?,
    density: Density
) {
    try {
        val width = 1200
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val androidCanvas = android.graphics.Canvas(bitmap)
        val composeCanvas = androidx.compose.ui.graphics.Canvas(androidCanvas)
        val drawScope = CanvasDrawScope()

        drawScope.draw(
            density = density,
            layoutDirection = LayoutDirection.Ltr,
            canvas = composeCanvas,
            size = androidx.compose.ui.geometry.Size(width.toFloat(), height.toFloat())
        ) {
            drawGraphContent(
                viewport = viewport,
                showGrid = showGrid,
                showAxes = showAxes,
                functions = functions,
                activeFunctionId = activeFunctionId,
                traceX = traceX
            )
        }

        // Save using MediaStore for generic modern Android compatibility
        val filename = "Graph_${System.currentTimeMillis()}.png"
        val contentValues = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, filename)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/png")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/GraphDrawer")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
        }

        val resolver = context.contentResolver
        val imageUri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)

        if (imageUri != null) {
            val outputStream: OutputStream? = resolver.openOutputStream(imageUri)
            if (outputStream != null) {
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, outputStream)
                outputStream.close()

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    contentValues.clear()
                    contentValues.put(MediaStore.MediaColumns.IS_PENDING, 0)
                    resolver.update(imageUri, contentValues, null, null)
                }

                Toast.makeText(context, "Saved to Pictures/GraphDrawer!", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(context, "Failed to open export stream", Toast.LENGTH_SHORT).show()
            }
        } else {
            Toast.makeText(context, "Failed to register image database", Toast.LENGTH_SHORT).show()
        }
    } catch (e: Exception) {
        Toast.makeText(context, "Export error: ${e.message}", Toast.LENGTH_SHORT).show()
    }
}
