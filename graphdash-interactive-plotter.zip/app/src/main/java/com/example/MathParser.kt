package com.example

import kotlin.math.*

sealed interface Token {
    object Plus : Token
    object Minus : Token
    object Mul : Token
    object Div : Token
    object Pow : Token
    object LParen : Token
    object RParen : Token
    data class Number(val value: Double) : Token
    object X : Token
    object Pi : Token
    object E : Token
    enum class FunType { SIN, COS, TAN, SQRT, LN, LOG, ABS }
    data class Function(val type: FunType) : Token
    object Eof : Token
}

sealed interface ExprNode {
    fun evaluate(x: Double): Double
}

data class NumberNode(val value: Double) : ExprNode {
    override fun evaluate(x: Double): Double = value
}

object VariableNode : ExprNode {
    override fun evaluate(x: Double): Double = x
}

data class BinaryOpNode(val left: ExprNode, val op: Token, val right: ExprNode) : ExprNode {
    override fun evaluate(x: Double): Double {
        val lVal = left.evaluate(x)
        val rVal = right.evaluate(x)
        return when (op) {
            Token.Plus -> lVal + rVal
            Token.Minus -> lVal - rVal
            Token.Mul -> lVal * rVal
            Token.Div -> if (rVal == 0.0) Double.NaN else lVal / rVal
            Token.Pow -> lVal.pow(rVal)
            else -> Double.NaN
        }
    }
}

data class UnaryOpNode(val op: Token, val expr: ExprNode) : ExprNode {
    override fun evaluate(x: Double): Double {
        val valExpr = expr.evaluate(x)
        return when (op) {
            Token.Plus -> valExpr
            Token.Minus -> -valExpr
            else -> Double.NaN
        }
    }
}

data class FunNode(val type: Token.FunType, val expr: ExprNode) : ExprNode {
    override fun evaluate(x: Double): Double {
        val inner = expr.evaluate(x)
        return when (type) {
            Token.FunType.SIN -> sin(inner)
            Token.FunType.COS -> cos(inner)
            Token.FunType.TAN -> tan(inner)
            Token.FunType.SQRT -> if (inner < 0.0) Double.NaN else sqrt(inner)
            Token.FunType.LN -> if (inner <= 0.0) Double.NaN else ln(inner)
            Token.FunType.LOG -> if (inner <= 0.0) Double.NaN else log10(inner)
            Token.FunType.ABS -> abs(inner)
        }
    }
}

object MathParser {
    fun tokenize(expr: String): List<Token> {
        val tokens = mutableListOf<Token>()
        var i = 0
        val n = expr.length

        while (i < n) {
            val c = expr[i]
            if (c.isWhitespace()) {
                i++
                continue
            }

            // Operator Symbols
            if (c == '+') {
                tokens.add(Token.Plus)
                i++
                continue
            }
            if (c == '-') {
                tokens.add(Token.Minus)
                i++
                continue
            }
            if (c == '*' || c == '×' || c == '•') {
                tokens.add(Token.Mul)
                i++
                continue
            }
            if (c == '/' || c == '÷') {
                tokens.add(Token.Div)
                i++
                continue
            }
            if (c == '^') {
                tokens.add(Token.Pow)
                i++
                continue
            }
            if (c == '(') {
                tokens.add(Token.LParen)
                i++
                continue
            }
            if (c == ')') {
                tokens.add(Token.RParen)
                i++
                continue
            }

            // Numeric literals
            if (c.isDigit() || c == '.') {
                val start = i
                var hasDot = c == '.'
                i++
                while (i < n) {
                    val nextChar = expr[i]
                    if (nextChar.isDigit()) {
                        i++
                    } else if (nextChar == '.' && !hasDot) {
                        hasDot = true
                        i++
                    } else {
                        break
                    }
                }
                val numStr = expr.substring(start, i)
                val value = numStr.toDoubleOrNull() ?: 0.0
                tokens.add(Token.Number(value))
                continue
            }

            // Words, constants, functions, variables
            if (c.isLetter() || c == 'π' || c == 'θ') {
                val start = i
                i++
                while (i < n && (expr[i].isLetterOrDigit() || expr[i] == 'π' || expr[i] == 'θ')) {
                    i++
                }
                val word = expr.substring(start, i).lowercase()
                when (word) {
                    "x", "θ" -> tokens.add(Token.X)
                    "pi", "π" -> tokens.add(Token.Pi)
                    "e" -> tokens.add(Token.E)
                    "sin" -> tokens.add(Token.Function(Token.FunType.SIN))
                    "cos" -> tokens.add(Token.Function(Token.FunType.COS))
                    "tan" -> tokens.add(Token.Function(Token.FunType.TAN))
                    "sqrt", "√" -> tokens.add(Token.Function(Token.FunType.SQRT))
                    "ln" -> tokens.add(Token.Function(Token.FunType.LN))
                    "log" -> tokens.add(Token.Function(Token.FunType.LOG))
                    "abs" -> tokens.add(Token.Function(Token.FunType.ABS))
                    else -> {
                        // For unexpected alphabetic letters, split or default
                        if (word.length > 1) {
                            // Backtrack to parse each character separately to support syntax like "ax" -> "a" * "x"
                            i = start + 1
                            val single = word[0].toString()
                            if (single == "x" || single == "θ") {
                                tokens.add(Token.X)
                            } else if (single == "e") {
                                tokens.add(Token.E)
                            } else if (single == "π") {
                                tokens.add(Token.Pi)
                            } else {
                                tokens.add(Token.X) // Default variable fallback
                            }
                        } else {
                            tokens.add(Token.X)
                        }
                    }
                }
                continue
            }

            // Ignore unexpected characters gracefully
            i++
        }
        return tokens
    }

    fun insertImplicitMultiplication(tokens: List<Token>): List<Token> {
        if (tokens.isEmpty()) return tokens
        val result = mutableListOf<Token>()
        result.add(tokens[0])

        for (j in 1 until tokens.size) {
            val prev = tokens[j - 1]
            val curr = tokens[j]

            val needsMul = when (prev) {
                is Token.Number -> when (curr) {
                    is Token.X, Token.Pi, Token.E, is Token.Function, Token.LParen, is Token.Number -> true
                    else -> false
                }
                is Token.X, Token.Pi, Token.E -> when (curr) {
                    is Token.X, Token.Pi, Token.E, is Token.Function, Token.LParen, is Token.Number -> true
                    else -> false
                }
                is Token.RParen -> when (curr) {
                    is Token.X, Token.Pi, Token.E, is Token.Function, Token.LParen, is Token.Number -> true
                    else -> false
                }
                else -> false
            }

            if (needsMul) {
                result.add(Token.Mul)
            }
            result.add(curr)
        }
        return result
    }

    class Parser(private val tokens: List<Token>) {
        private val list = tokens + Token.Eof
        private var index = 0

        private fun peek(): Token = list[index]
        private fun consume(): Token = list[index++]

        fun parse(): ExprNode {
            val node = parseExpression()
            if (peek() != Token.Eof) {
                throw IllegalArgumentException("Unexpected content at the end of the expression")
            }
            return node
        }

        private fun parseExpression(): ExprNode {
            var node = parseTerm()
            while (peek() == Token.Plus || peek() == Token.Minus) {
                val op = consume()
                val right = parseTerm()
                node = BinaryOpNode(node, op, right)
            }
            return node
        }

        private fun parseTerm(): ExprNode {
            var node = parseFactor()
            while (peek() == Token.Mul || peek() == Token.Div) {
                val op = consume()
                val right = parseFactor()
                node = BinaryOpNode(node, op, right)
            }
            return node
        }

        private fun parseFactor(): ExprNode {
            val node = parseBase()
            if (peek() == Token.Pow) {
                val op = consume()
                val right = parseFactor()
                return BinaryOpNode(node, op, right)
            }
            return node
        }

        private fun parseBase(): ExprNode {
            return when (val token = peek()) {
                Token.Plus -> {
                    consume()
                    UnaryOpNode(Token.Plus, parseBase())
                }
                Token.Minus -> {
                    consume()
                    UnaryOpNode(Token.Minus, parseBase())
                }
                is Token.Number -> {
                    consume()
                    NumberNode(token.value)
                }
                Token.X -> {
                    consume()
                    VariableNode
                }
                Token.Pi -> {
                    consume()
                    NumberNode(PI)
                }
                Token.E -> {
                    consume()
                    NumberNode(E)
                }
                Token.LParen -> {
                    consume()
                    val expr = parseExpression()
                    if (consume() != Token.RParen) {
                        throw IllegalArgumentException("Missing closing parenthesis")
                    }
                    expr
                }
                is Token.Function -> {
                    val funToken = consume() as Token.Function
                    if (peek() != Token.LParen) {
                        // User typed "sin x" instead of "sin(x)"
                        val arg = parseBase()
                        FunNode(funToken.type, arg)
                    } else {
                        consume() // Consume LParen
                        val expr = parseExpression()
                        if (consume() != Token.RParen) {
                            throw IllegalArgumentException("Missing closing parenthesis for function")
                        }
                        FunNode(funToken.type, expr)
                    }
                }
                else -> {
                    throw IllegalArgumentException("Invalid expression component")
                }
            }
        }
    }

    fun parse(expr: String): ExprNode {
        val tokens = tokenize(expr)
        val processed = insertImplicitMultiplication(tokens)
        return Parser(processed).parse()
    }
}
