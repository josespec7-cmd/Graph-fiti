package com.example

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlin.math.abs

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GraphDashboard(
    modifier: Modifier = Modifier,
    viewModel: GraphViewModel = viewModel()
) {
    val uiState by viewModel.uiState.collectAsState()
    val context = LocalContext.current
    val density = LocalDensity.current
    var showSettings by remember { mutableStateOf(false) }
    var showHistory by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        contentWindowInsets = WindowInsets.safeDrawing
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color(0xFF0F172A))
                .padding(innerPadding)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // ZONE 1: Canvas Area (Visual Graph Canvas on Top)
                Box(
                    modifier = Modifier
                        .weight(1.1f)
                        .fillMaxWidth()
                        .border(1.dp, Color(0xFF334155))
                ) {
                    InteractiveGraphCanvas(
                        viewModel = viewModel,
                        uiState = uiState,
                        modifier = Modifier.fillMaxSize().testTag("graph_canvas")
                    )

                    // Top Right Toolbar Overlay
                    Row(
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .background(Color(0xCC0F172A), shape = RoundedCornerShape(12.dp))
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        IconButton(
                            onClick = {
                                val vp = uiState.viewport
                                viewModel.updateViewportScale(1.25, (vp.xMin + vp.xMax) / 2.0, (vp.yMin + vp.yMax) / 2.0)
                            },
                            modifier = Modifier.size(38.dp).testTag("zoom_in_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = "Zoom In", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(
                            onClick = {
                                val vp = uiState.viewport
                                viewModel.updateViewportScale(0.8, (vp.xMin + vp.xMax) / 2.0, (vp.yMin + vp.yMax) / 2.0)
                            },
                            modifier = Modifier.size(38.dp).testTag("zoom_out_button")
                        ) {
                            Icon(Icons.Default.Remove, contentDescription = "Zoom Out", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(
                            onClick = { viewModel.resetView() },
                            modifier = Modifier.size(38.dp).testTag("reset_view_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset View", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                        IconButton(
                            onClick = {
                                exportAndSaveGraph(
                                    context = context,
                                    viewport = uiState.viewport,
                                    showGrid = uiState.showGrid,
                                    showAxes = uiState.showAxes,
                                    functions = uiState.functions,
                                    activeFunctionId = uiState.activeFunctionId,
                                    traceX = uiState.traceX,
                                    density = density
                                )
                            },
                            modifier = Modifier.size(38.dp).testTag("download_graph_button")
                        ) {
                            Icon(Icons.Default.Download, contentDescription = "Save PNG", tint = Color(0xFF00E5FF), modifier = Modifier.size(20.dp))
                        }
                        IconButton(
                            onClick = { showSettings = !showSettings },
                            modifier = Modifier.size(38.dp).testTag("settings_button")
                        ) {
                            Icon(Icons.Default.Settings, contentDescription = "Settings", tint = Color.White, modifier = Modifier.size(20.dp))
                        }
                    }

                    // Sliding Settings Panel Overlay
                    androidx.compose.animation.AnimatedVisibility(
                        visible = showSettings,
                        enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
                        exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(top = 70.dp, end = 12.dp)
                            .width(280.dp)
                            .background(Color(0xF91E293B), shape = RoundedCornerShape(12.dp))
                            .border(1.dp, Color(0xFF475569), shape = RoundedCornerShape(12.dp))
                            .padding(14.dp)
                    ) {
                        SettingsPanel(
                            viewModel = viewModel,
                            uiState = uiState,
                            onClose = { showSettings = false }
                        )
                    }
                }

                // ZONE 2: Controls & Keypad Section on bottom
                Column(
                    modifier = Modifier
                        .weight(1.0f)
                        .fillMaxWidth()
                        .background(Color(0xFF090D16))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    // TAB SELECT BAR (Multi-Function management)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            modifier = Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            uiState.functions.forEach { fn ->
                                val isActive = fn.id == uiState.activeFunctionId
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(if (isActive) Color(0xFF1E293B) else Color(0xFF0F172A))
                                        .border(
                                            1.dp,
                                            if (isActive) fn.color else Color(0xFF334155),
                                            RoundedCornerShape(8.dp)
                                        )
                                        .clickable { viewModel.selectTab(fn.id) }
                                        .padding(horizontal = 8.dp, vertical = 6.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                                ) {
                                    Icon(
                                        imageVector = if (fn.isVisible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                        contentDescription = "Toggle Visibility",
                                        tint = if (fn.isVisible) fn.color else Color(0xFF64748B),
                                        modifier = Modifier
                                            .size(18.dp)
                                            .clickable { viewModel.toggleVisibility(fn.id) }
                                    )
                                    Text(
                                        text = fn.tabLabel,
                                        color = if (isActive) Color.White else Color(0xFF94A3B8),
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    if (uiState.functions.size > 1) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Delete Function",
                                            tint = Color(0xFFEF4444),
                                            modifier = Modifier
                                                .size(14.dp)
                                                .clickable { viewModel.removeFunction(fn.id) }
                                        )
                                    }
                                }
                            }

                            // [+ Add] Button
                            if (uiState.functions.size < 5) {
                                Button(
                                    onClick = { viewModel.addFunction() },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp).testTag("add_function_button")
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Add", tint = Color(0xFF00E5FF), modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Add", color = Color(0xFF00E5FF), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // EQUATION INPUT BAR WITH LIVE SYNTAX VALIDATION
                    val activeFn = uiState.functions.find { it.id == uiState.activeFunctionId }
                    if (activeFn != null) {
                        val isInvalid = !activeFn.isValid && activeFn.formula.isNotEmpty()
                        Column(modifier = Modifier.fillMaxWidth()) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(44.dp)
                                    .background(Color(0xFF0F172A), RoundedCornerShape(8.dp))
                                    .border(
                                        1.dp,
                                        if (isInvalid) Color(0xFFEF4444) else activeFn.color,
                                        RoundedCornerShape(8.dp)
                                    )
                                    .padding(horizontal = 10.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${activeFn.tabLabel}(x) =",
                                    color = activeFn.color,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(end = 6.dp)
                                )

                                // Real editable Text Field with cursor tracking, read-only to suppress system keyboard
                                val textVal = TextFieldValue(
                                    text = activeFn.formula,
                                    selection = TextRange(uiState.cursorPosition.coerceIn(0, activeFn.formula.length))
                                )

                                BasicTextField(
                                    value = textVal,
                                    onValueChange = { newVal ->
                                        // Update selection/cursor position
                                        viewModel.setCursorPos(newVal.selection.start)
                                    },
                                    readOnly = true, // SUPPRESS NATIVE KEYBOARD
                                    textStyle = TextStyle(
                                        color = Color.White,
                                        fontSize = 15.sp,
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.Medium
                                    ),
                                    cursorBrush = SolidColor(activeFn.color),
                                    modifier = Modifier.weight(1f).testTag("formula_input")
                                )

                                if (activeFn.formula.isNotEmpty()) {
                                    IconButton(
                                        onClick = { viewModel.clearActiveFormula() },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(Icons.Default.Clear, contentDescription = "Clear", tint = Color(0xFF64748B), modifier = Modifier.size(16.dp))
                                    }
                                }
                            }

                            // Error/Validation warning
                            AnimatedVisibility(visible = isInvalid) {
                                Text(
                                    text = "Check your expression",
                                    color = Color(0xFFEF4444),
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(start = 4.dp, top = 2.dp),
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // PRESET EXPRESSION BAR
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Presets:", color = Color(0xFF64748B), fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        listOf("Linear", "Quadratic", "Trig", "Binomial").forEach { preset ->
                            SuggestionChip(
                                onClick = { viewModel.applyPreset(preset) },
                                label = { Text(preset, fontSize = 11.sp, color = Color.White) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = Color(0xFF1E293B)
                                ),
                                border = SuggestionChipDefaults.suggestionChipBorder(
                                    borderColor = Color(0xFF334155),
                                    enabled = true
                                ),
                                modifier = Modifier.testTag("preset_${preset.lowercase()}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // CURSOR & HISTORY TOOL BAR
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Move cursor left
                        Button(
                            onClick = { viewModel.moveCursorLeft() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .testTag("btn_cursor_left")
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Move Cursor Left",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Left", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        // Move cursor right
                        Button(
                            onClick = { viewModel.moveCursorRight() },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1E293B)),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(36.dp)
                                .testTag("btn_cursor_right")
                        ) {
                            Text("Right", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.Default.ArrowForward,
                                contentDescription = "Move Cursor Right",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                        }

                        // History button to show overlay
                        Button(
                            onClick = { showHistory = !showHistory },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (showHistory) Color(0xFF00E5FF) else Color(0xFF1E293B)
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(0.dp),
                            modifier = Modifier
                                .weight(1.5f)
                                .height(36.dp)
                                .testTag("btn_history")
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = "History",
                                tint = if (showHistory) Color(0xFF0F172A) else Color(0xFFFFB300),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "History Check",
                                color = if (showHistory) Color(0xFF0F172A) else Color.White,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    if (showHistory) {
                        HistoryPanel(
                            viewModel = viewModel,
                            uiState = uiState,
                            onClose = { showHistory = false }
                        )
                    } else {
                        // CUSTOM MATHEMATICAL KEYPAD
                        MathKeypad(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsPanel(
    viewModel: GraphViewModel,
    uiState: GraphUiState,
    onClose: () -> Unit
) {
    var xMinInput by remember(uiState.viewport.xMin) { mutableStateOf(String.format("%.2f", uiState.viewport.xMin)) }
    var xMaxInput by remember(uiState.viewport.xMax) { mutableStateOf(String.format("%.2f", uiState.viewport.xMax)) }
    var yMinInput by remember(uiState.viewport.yMin) { mutableStateOf(String.format("%.2f", uiState.viewport.yMin)) }
    var yMaxInput by remember(uiState.viewport.yMax) { mutableStateOf(String.format("%.2f", uiState.viewport.yMax)) }

    val context = LocalContext.current

    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Advanced Settings", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            IconButton(onClick = onClose, modifier = Modifier.size(24.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White, modifier = Modifier.size(16.dp))
            }
        }

        Divider(color = Color(0xFF475569), modifier = Modifier.padding(vertical = 4.dp))

        // Grid Viewports Manual boundaries
        Text("Manual Range limits", color = Color(0xFF94A3B8), fontSize = 11.sp, fontWeight = FontWeight.Bold)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("X Min", color = Color(0xFF64748B), fontSize = 10.sp)
                OutlinedTextField(
                    value = xMinInput,
                    onValueChange = { xMinInput = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("xmin_input")
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("X Max", color = Color(0xFF64748B), fontSize = 10.sp)
                OutlinedTextField(
                    value = xMaxInput,
                    onValueChange = { xMaxInput = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("xmax_input")
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text("Y Min", color = Color(0xFF64748B), fontSize = 10.sp)
                OutlinedTextField(
                    value = yMinInput,
                    onValueChange = { yMinInput = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ymin_input")
                )
            }
            Column(modifier = Modifier.weight(1f)) {
                Text("Y Max", color = Color(0xFF64748B), fontSize = 10.sp)
                OutlinedTextField(
                    value = yMaxInput,
                    onValueChange = { yMaxInput = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 12.sp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color(0xFF00E5FF),
                        unfocusedBorderColor = Color(0xFF475569)
                    ),
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth().height(48.dp).testTag("ymax_input")
                )
            }
        }

        Button(
            onClick = {
                val xMinVal = xMinInput.toDoubleOrNull()
                val xMaxVal = xMaxInput.toDoubleOrNull()
                val yMinVal = yMinInput.toDoubleOrNull()
                val yMaxVal = yMaxInput.toDoubleOrNull()

                if (xMinVal != null && xMaxVal != null && yMinVal != null && yMaxVal != null) {
                    if (xMinVal < xMaxVal && yMinVal < yMaxVal) {
                        viewModel.setViewport(xMinVal, xMaxVal, yMinVal, yMaxVal)
                        Toast.makeText(context, "Viewport updated!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Min must be less than Max", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    Toast.makeText(context, "Invalid range inputs", Toast.LENGTH_SHORT).show()
                }
            },
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00E5FF)),
            modifier = Modifier.fillMaxWidth().height(36.dp).testTag("apply_settings_button"),
            contentPadding = PaddingValues(0.dp)
        ) {
            Text("Apply Range", color = Color(0xFF0F172A), fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }

        Divider(color = Color(0xFF475569), modifier = Modifier.padding(vertical = 4.dp))

        // Checkboxes / Toggles
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.GridOn, contentDescription = "Grid", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Show Grid", color = Color.White, fontSize = 12.sp)
            }
            Checkbox(
                checked = uiState.showGrid,
                onCheckedChange = { viewModel.toggleGrid(it) },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00E5FF)),
                modifier = Modifier.testTag("grid_checkbox")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.HorizontalRule, contentDescription = "Axes", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Show Axes", color = Color.White, fontSize = 12.sp)
            }
            Checkbox(
                checked = uiState.showAxes,
                onCheckedChange = { viewModel.toggleAxes(it) },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00E5FF)),
                modifier = Modifier.testTag("axes_checkbox")
            )
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.AspectRatio, contentDescription = "Equal Scale", tint = Color(0xFF94A3B8), modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Equal Scale", color = Color.White, fontSize = 12.sp)
            }
            Checkbox(
                checked = uiState.equalScale,
                onCheckedChange = { viewModel.toggleEqualScale(it, 1f, 1f) },
                colors = CheckboxDefaults.colors(checkedColor = Color(0xFF00E5FF)),
                modifier = Modifier.testTag("equal_scale_checkbox")
            )
        }
    }
}

@Composable
fun MathKeypad(viewModel: GraphViewModel) {
    val keys = listOf(
        listOf("sin", "cos", "tan", "sqrt", "^", "⌫"),
        listOf("x", "π", "e", "(", ")", "C"),
        listOf("7", "8", "9", "÷", "x²", "+"),
        listOf("4", "5", "6", "×", "-", "."),
        listOf("1", "2", "3", "0", "ln", "abs")
    )

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        keys.forEach { row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                row.forEach { label ->
                    val isAction = label == "⌫" || label == "C"
                    val isDigit = label.firstOrNull()?.isDigit() == true || label == "."
                    val isOp = label == "+" || label == "-" || label == "×" || label == "÷" || label == "^" || label == "x²"

                    val (containerColor, contentColor) = when {
                        isAction -> {
                            if (label == "C") {
                                Pair(Color(0xFF7F1D1D), Color(0xFFFCA5A5)) // Crimson red clear
                            } else {
                                Pair(Color(0xFF334155), Color(0xFF94A3B8)) // Deep gray back
                            }
                        }
                        isDigit -> Pair(Color(0xFF1E293B), Color.White) // Slate number key
                        isOp -> Pair(Color(0xFF0F172A), Color(0xFF00E5FF)) // Navy operator key, bright teal text
                        else -> Pair(Color(0xFF1E293B), Color(0xFFC084FC)) // lavender function keys
                    }

                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .height(38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(containerColor)
                            .clickable {
                                when (label) {
                                    "C" -> viewModel.clearActiveFormula()
                                    "⌫" -> viewModel.deleteLast()
                                    "sin", "cos", "tan", "sqrt", "ln", "abs" -> viewModel.insertAtCursor("$label(")
                                    "x" -> viewModel.insertAtCursor("x")
                                    "π" -> viewModel.insertAtCursor("π")
                                    "e" -> viewModel.insertAtCursor("e")
                                    "x²" -> viewModel.insertAtCursor("^2")
                                    "×" -> viewModel.insertAtCursor("*")
                                    "÷" -> viewModel.insertAtCursor("/")
                                    else -> viewModel.insertAtCursor(label)
                                }
                            }
                            .testTag("keypad_btn_$label"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = label,
                            color = contentColor,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HistoryPanel(
    viewModel: GraphViewModel,
    uiState: GraphUiState,
    onClose: () -> Unit
) {
    val context = LocalContext.current
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(206.dp)
            .background(Color(0xFF0F172A), RoundedCornerShape(12.dp))
            .border(1.dp, Color(0xFF334155), RoundedCornerShape(12.dp))
            .padding(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.History,
                    contentDescription = "History Icon",
                    tint = Color(0xFFFFB300),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Expression History",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }
            Text(
                text = "Close ×",
                color = Color(0xFF00E5FF),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .clip(RoundedCornerShape(4.dp))
                    .clickable { onClose() }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        if (uiState.history.isEmpty()) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "No formulas in history yet.\nEnter some expressions above to build history!",
                    color = Color(0xFF64748B),
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(uiState.history) { formula ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF1E293B))
                            .clickable {
                                viewModel.updateActiveFormula(formula, formula.length)
                                Toast.makeText(context, "Restored: $formula", Toast.LENGTH_SHORT).show()
                                onClose()
                            }
                            .padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ShowChart,
                                contentDescription = "Graph icon",
                                tint = Color(0xFF00E5FF),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = formula,
                                color = Color.White,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                        Icon(
                            imageVector = Icons.Default.ArrowForward,
                            contentDescription = "Apply Formula",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }
            }
        }
    }
}
